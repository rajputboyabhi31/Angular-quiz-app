export const environment = {
  production: true,
  questionsListUrl: 'assets/questions.json'
};
