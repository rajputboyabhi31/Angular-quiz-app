export class question {
    id: number;
    question: string;
    answer: []
}